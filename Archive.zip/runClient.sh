# Create a client instance and connect to the coordinator. Must be ran after coordinator is set up
java -cp TPC.jar dcs.os.Client localhost:9000 &
